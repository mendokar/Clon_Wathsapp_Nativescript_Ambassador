import { LoginComponent} from "./modules/login/login.component";
import { MenuComponent } from "./modules/menu/menu.component";
import { RegistrarComponent} from "./modules/registrar/registrar.component";

export const Routes =[
    {path:"",component:LoginComponent},
    {path:"menu",component:MenuComponent},
    {path:"registrar",component:RegistrarComponent}
]

export const NavigateRoutes =[
    LoginComponent,
    MenuComponent,
    RegistrarComponent
]