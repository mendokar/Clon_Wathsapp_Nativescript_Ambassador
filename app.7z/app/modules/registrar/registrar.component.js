"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var color_1 = require("tns-core-modules/color/color");
var router_1 = require("nativescript-angular/router");
var firebase = require("nativescript-plugin-firebase");
var dialogs = require("ui/dialogs");
var RegistrarComponent = (function () {
    function RegistrarComponent(routEx) {
        this.routEx = routEx;
    }
    RegistrarComponent.prototype.onTouchButton = function (args) {
        var seleccion = args.action;
        var grid = args.object;
        if (seleccion == "up") {
            grid.backgroundColor = new color_1.Color("#002aff");
        }
        else {
            grid.backgroundColor = new color_1.Color("#4ecdc4");
        }
    };
    RegistrarComponent.prototype.goBack = function () {
        this.routEx.back();
    };
    RegistrarComponent.prototype.registroFacebook = function () {
        alert("Aqui se registra con Facebook");
    };
    RegistrarComponent.prototype.registroGmail = function () {
        alert("Aqui se registra con Gmail");
    };
    RegistrarComponent.prototype.registrarUsuario = function () {
        firebase.createUser({
            email: 'eddyverbruggen@gmail.com',
            password: 'firebase'
        }).then(function (result) {
            dialogs.alert({
                title: "User created",
                message: "userid: " + result.key,
                okButtonText: "Nice!"
            });
        }, function (errorMessage) {
            dialogs.alert({
                title: "No user created",
                message: errorMessage,
                okButtonText: "OK, got it"
            });
        });
    };
    return RegistrarComponent;
}());
RegistrarComponent = __decorate([
    core_1.Component({
        selector: "app-registrar",
        templateUrl: "./modules/registrar/registrar.component.html",
        styleUrls: ["./modules/registrar/registrar.component.css"]
    }),
    __metadata("design:paramtypes", [router_1.RouterExtensions])
], RegistrarComponent);
exports.RegistrarComponent = RegistrarComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVnaXN0cmFyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInJlZ2lzdHJhci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMEM7QUFHMUMsc0RBQXFEO0FBQ3JELHNEQUE4RDtBQUc5RCx1REFBMEQ7QUFDMUQsb0NBQXNDO0FBUXRDLElBQWEsa0JBQWtCO0lBRTNCLDRCQUFvQixNQUF1QjtRQUF2QixXQUFNLEdBQU4sTUFBTSxDQUFpQjtJQUUzQyxDQUFDO0lBR0QsMENBQWEsR0FBYixVQUFjLElBQTJCO1FBQ3JDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDNUIsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUUvQixFQUFFLENBQUMsQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNwQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksYUFBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hELENBQUM7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNKLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxhQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFaEQsQ0FBQztJQUNMLENBQUM7SUFFRCxtQ0FBTSxHQUFOO1FBQ0ksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRUQsNkNBQWdCLEdBQWhCO1FBQ0ksS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVELDBDQUFhLEdBQWI7UUFDSSxLQUFLLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBR0QsNkNBQWdCLEdBQWhCO1FBRUksUUFBUSxDQUFDLFVBQVUsQ0FBQztZQUN4QixLQUFLLEVBQUUsMEJBQTBCO1lBQ2pDLFFBQVEsRUFBRSxVQUFVO1NBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQ0gsVUFBVSxNQUFNO1lBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFDWixLQUFLLEVBQUUsY0FBYztnQkFDckIsT0FBTyxFQUFFLFVBQVUsR0FBRyxNQUFNLENBQUMsR0FBRztnQkFDaEMsWUFBWSxFQUFFLE9BQU87YUFDdEIsQ0FBQyxDQUFBO1FBQ0osQ0FBQyxFQUNELFVBQVUsWUFBWTtZQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDO2dCQUNaLEtBQUssRUFBRSxpQkFBaUI7Z0JBQ3hCLE9BQU8sRUFBRSxZQUFZO2dCQUNyQixZQUFZLEVBQUUsWUFBWTthQUMzQixDQUFDLENBQUE7UUFDSixDQUFDLENBQ0osQ0FBQztJQUlBLENBQUM7SUFFTCx5QkFBQztBQUFELENBQUMsQUExREQsSUEwREM7QUExRFksa0JBQWtCO0lBTjlCLGdCQUFTLENBQUM7UUFDUCxRQUFRLEVBQUMsZUFBZTtRQUN4QixXQUFXLEVBQUMsOENBQThDO1FBQzFELFNBQVMsRUFBQyxDQUFDLDZDQUE2QyxDQUFDO0tBQzVELENBQUM7cUNBSTZCLHlCQUFnQjtHQUZsQyxrQkFBa0IsQ0EwRDlCO0FBMURZLGdEQUFrQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IFRvdWNoR2VzdHVyZUV2ZW50RGF0YSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2dlc3R1cmVzL2dlc3R1cmVzXCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2J1dHRvbi9idXR0b25cIjtcclxuaW1wb3J0IHsgQ29sb3IgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9jb2xvci9jb2xvclwiO1xyXG5pbXBvcnQgeyBSb3V0ZXJFeHRlbnNpb25zfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IERpYWxvZ09wdGlvbnMgfSBmcm9tIFwidWkvZGlhbG9nc1wiO1xyXG5cclxuaW1wb3J0IGZpcmViYXNlID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1wbHVnaW4tZmlyZWJhc2VcIik7XHJcbmltcG9ydCAqIGFzIGRpYWxvZ3MgZnJvbSBcInVpL2RpYWxvZ3NcIjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6XCJhcHAtcmVnaXN0cmFyXCIsXHJcbiAgICB0ZW1wbGF0ZVVybDpcIi4vbW9kdWxlcy9yZWdpc3RyYXIvcmVnaXN0cmFyLmNvbXBvbmVudC5odG1sXCIsXHJcbiAgICBzdHlsZVVybHM6W1wiLi9tb2R1bGVzL3JlZ2lzdHJhci9yZWdpc3RyYXIuY29tcG9uZW50LmNzc1wiXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIFJlZ2lzdHJhckNvbXBvbmVudHtcclxuICAgIFxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0RXg6Um91dGVyRXh0ZW5zaW9ucyl7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBvblRvdWNoQnV0dG9uKGFyZ3M6IFRvdWNoR2VzdHVyZUV2ZW50RGF0YSkge1xyXG4gICAgICAgIGxldCBzZWxlY2Npb24gPSBhcmdzLmFjdGlvbjtcclxuICAgICAgICBsZXQgZ3JpZCA9IDxCdXR0b24+YXJncy5vYmplY3Q7XHJcblxyXG4gICAgICAgIGlmIChzZWxlY2Npb24gPT0gXCJ1cFwiKSB7XHJcbiAgICAgICAgICAgIGdyaWQuYmFja2dyb3VuZENvbG9yID0gbmV3IENvbG9yKFwiIzAwMmFmZlwiKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBncmlkLmJhY2tncm91bmRDb2xvciA9IG5ldyBDb2xvcihcIiM0ZWNkYzRcIik7XHJcblxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBnb0JhY2soKXtcclxuICAgICAgICB0aGlzLnJvdXRFeC5iYWNrKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmVnaXN0cm9GYWNlYm9vaygpe1xyXG4gICAgICAgIGFsZXJ0KFwiQXF1aSBzZSByZWdpc3RyYSBjb24gRmFjZWJvb2tcIik7XHJcbiAgICB9XHJcblxyXG4gICAgcmVnaXN0cm9HbWFpbCgpe1xyXG4gICAgICAgIGFsZXJ0KFwiQXF1aSBzZSByZWdpc3RyYSBjb24gR21haWxcIik7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHJlZ2lzdHJhclVzdWFyaW8oKXtcclxuXHJcbiAgICAgICAgZmlyZWJhc2UuY3JlYXRlVXNlcih7XHJcbiAgICBlbWFpbDogJ2VkZHl2ZXJicnVnZ2VuQGdtYWlsLmNvbScsXHJcbiAgICBwYXNzd29yZDogJ2ZpcmViYXNlJ1xyXG4gIH0pLnRoZW4oXHJcbiAgICAgIGZ1bmN0aW9uIChyZXN1bHQpIHtcclxuICAgICAgICBkaWFsb2dzLmFsZXJ0KHtcclxuICAgICAgICAgIHRpdGxlOiBcIlVzZXIgY3JlYXRlZFwiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJ1c2VyaWQ6IFwiICsgcmVzdWx0LmtleSxcclxuICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJOaWNlIVwiXHJcbiAgICAgICAgfSlcclxuICAgICAgfSxcclxuICAgICAgZnVuY3Rpb24gKGVycm9yTWVzc2FnZSkge1xyXG4gICAgICAgIGRpYWxvZ3MuYWxlcnQoe1xyXG4gICAgICAgICAgdGl0bGU6IFwiTm8gdXNlciBjcmVhdGVkXCIsXHJcbiAgICAgICAgICBtZXNzYWdlOiBlcnJvck1lc3NhZ2UsXHJcbiAgICAgICAgICBva0J1dHRvblRleHQ6IFwiT0ssIGdvdCBpdFwiXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICk7XHJcblxyXG5cclxuXHJcbiAgICB9XHJcbiAgICBcclxufSJdfQ==