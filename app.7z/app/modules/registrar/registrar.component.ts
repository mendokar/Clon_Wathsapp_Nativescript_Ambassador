import { Component } from "@angular/core";
import { TouchGestureEventData } from "tns-core-modules/ui/gestures/gestures";
import { Button } from "tns-core-modules/ui/button/button";
import { Color } from "tns-core-modules/color/color";
import { RouterExtensions} from "nativescript-angular/router";
import { DialogOptions } from "ui/dialogs";

import firebase = require("nativescript-plugin-firebase");
import * as dialogs from "ui/dialogs";

@Component({
    selector:"app-registrar",
    templateUrl:"./modules/registrar/registrar.component.html",
    styleUrls:["./modules/registrar/registrar.component.css"]
})

export class RegistrarComponent{
    
    constructor(private routEx:RouterExtensions){

    }


    onTouchButton(args: TouchGestureEventData) {
        let seleccion = args.action;
        let grid = <Button>args.object;

        if (seleccion == "up") {
            grid.backgroundColor = new Color("#002aff");
        } else {
            grid.backgroundColor = new Color("#4ecdc4");

        }
    }

    goBack(){
        this.routEx.back();
    }

    registroFacebook(){
        alert("Aqui se registra con Facebook");
    }

    registroGmail(){
        alert("Aqui se registra con Gmail");
    }


    registrarUsuario(){

        firebase.createUser({
    email: 'eddyverbruggen@gmail.com',
    password: 'firebase'
  }).then(
      function (result) {
        dialogs.alert({
          title: "User created",
          message: "userid: " + result.key,
          okButtonText: "Nice!"
        })
      },
      function (errorMessage) {
        dialogs.alert({
          title: "No user created",
          message: errorMessage,
          okButtonText: "OK, got it"
        })
      }
  );



    }
    
}