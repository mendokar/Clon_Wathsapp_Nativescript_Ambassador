"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var color_1 = require("tns-core-modules/color/color");
var router_1 = require("nativescript-angular/router");
var firebase = require("nativescript-plugin-firebase");
var LoginComponent = (function () {
    function LoginComponent(page, routEx) {
        this.page = page;
        this.routEx = routEx;
        // Your TypeScript logic goes here
        this.isTurnedOn = false;
        this.mostrarPass = true;
        page.actionBarHidden = true;
    }
    LoginComponent.prototype.onTouchButton = function (args) {
        var seleccion = args.action;
        var grid = args.object;
        if (seleccion == "up") {
            grid.backgroundColor = new color_1.Color("#002aff");
        }
        else {
            grid.backgroundColor = new color_1.Color("#4ecdc4");
        }
    };
    LoginComponent.prototype.mostrarClave = function () {
        if (this.mostrarPass == true) {
            this.isTurnedOn = false;
            this.mostrarPass = false;
        }
        else {
            this.isTurnedOn = true;
            this.mostrarPass = true;
        }
    };
    LoginComponent.prototype.pantallaRegistrar = function () {
        this.routEx.navigate(["registrar"], {
            transition: {
                name: "slideTop",
                duration: 200,
                curve: "linear"
            }
        });
    };
    LoginComponent.prototype.reaizarLogin = function () {
        firebase.login({
            type: firebase.LoginType.PASSWORD,
            passwordOptions: {
                email: 'eddyverbruggen@gmail.com',
                password: 'firebase'
            }
        }).then(function (result) {
            JSON.stringify(result);
            console.log(result.uid);
        }, function (errorMessage) {
            console.log(errorMessage);
        });
    };
    return LoginComponent;
}());
LoginComponent = __decorate([
    core_1.Component({
        selector: "app-login",
        templateUrl: "./modules/login/login.component.html",
        styleUrls: ["./modules/login/login.component.css"]
    }),
    __metadata("design:paramtypes", [page_1.Page, router_1.RouterExtensions])
], LoginComponent);
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibG9naW4uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQTBDO0FBQzFDLGdDQUErQjtBQUcvQixzREFBcUQ7QUFDckQsc0RBQThEO0FBRTlELHVEQUEwRDtBQVExRCxJQUFhLGNBQWM7SUFJdkIsd0JBQW9CLElBQVUsRUFBUyxNQUF1QjtRQUExQyxTQUFJLEdBQUosSUFBSSxDQUFNO1FBQVMsV0FBTSxHQUFOLE1BQU0sQ0FBaUI7UUFIOUQsa0NBQWtDO1FBQzNCLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDNUIsZ0JBQVcsR0FBWSxJQUFJLENBQUM7UUFFL0IsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7SUFDaEMsQ0FBQztJQUVELHNDQUFhLEdBQWIsVUFBYyxJQUEyQjtRQUNyQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzVCLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFL0IsRUFBRSxDQUFDLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDcEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLGFBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNoRCxDQUFDO1FBQUMsSUFBSSxDQUFDLENBQUM7WUFDSixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksYUFBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRWhELENBQUM7SUFDTCxDQUFDO0lBR0QscUNBQVksR0FBWjtRQUNJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUN4QixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztRQUM3QixDQUFDO1FBQUMsSUFBSSxDQUFDLENBQUM7WUFDSixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztZQUN2QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUM1QixDQUFDO0lBRUwsQ0FBQztJQUVELDBDQUFpQixHQUFqQjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUM7WUFDL0IsVUFBVSxFQUFDO2dCQUNQLElBQUksRUFBQyxVQUFVO2dCQUNmLFFBQVEsRUFBQyxHQUFHO2dCQUNaLEtBQUssRUFBQyxRQUFRO2FBQ2pCO1NBQ0osQ0FDQSxDQUFBO0lBRUwsQ0FBQztJQUVELHFDQUFZLEdBQVo7UUFDQSxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQ2YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxTQUFTLENBQUMsUUFBUTtZQUNqQyxlQUFlLEVBQUU7Z0JBQ2YsS0FBSyxFQUFFLDBCQUEwQjtnQkFDakMsUUFBUSxFQUFFLFVBQVU7YUFDckI7U0FDRixDQUFDLENBQUMsSUFBSSxDQUNILFVBQVUsTUFBTTtZQUNkLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDMUIsQ0FBQyxFQUNELFVBQVUsWUFBWTtZQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzVCLENBQUMsQ0FDSixDQUFDO0lBQ0EsQ0FBQztJQU9MLHFCQUFDO0FBQUQsQ0FBQyxBQW5FRCxJQW1FQztBQW5FWSxjQUFjO0lBTjFCLGdCQUFTLENBQUM7UUFDUCxRQUFRLEVBQUUsV0FBVztRQUNyQixXQUFXLEVBQUUsc0NBQXNDO1FBQ25ELFNBQVMsRUFBRSxDQUFDLHFDQUFxQyxDQUFDO0tBRXJELENBQUM7cUNBSzRCLFdBQUksRUFBZ0IseUJBQWdCO0dBSnJELGNBQWMsQ0FtRTFCO0FBbkVZLHdDQUFjIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XHJcbmltcG9ydCB7IFRvdWNoR2VzdHVyZUV2ZW50RGF0YSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2dlc3R1cmVzL2dlc3R1cmVzXCI7XHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJ1aS9idXR0b25cIjtcclxuaW1wb3J0IHsgQ29sb3IgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9jb2xvci9jb2xvclwiO1xyXG5pbXBvcnQgeyBSb3V0ZXJFeHRlbnNpb25zfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XHJcblxyXG5pbXBvcnQgZmlyZWJhc2UgPSByZXF1aXJlKFwibmF0aXZlc2NyaXB0LXBsdWdpbi1maXJlYmFzZVwiKTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6IFwiYXBwLWxvZ2luXCIsXHJcbiAgICB0ZW1wbGF0ZVVybDogXCIuL21vZHVsZXMvbG9naW4vbG9naW4uY29tcG9uZW50Lmh0bWxcIixcclxuICAgIHN0eWxlVXJsczogW1wiLi9tb2R1bGVzL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5jc3NcIl1cclxuXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBMb2dpbkNvbXBvbmVudCB7XHJcbiAgICAvLyBZb3VyIFR5cGVTY3JpcHQgbG9naWMgZ29lcyBoZXJlXHJcbiAgICBwdWJsaWMgaXNUdXJuZWRPbjogQm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIG1vc3RyYXJQYXNzOiBCb29sZWFuID0gdHJ1ZTtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgcGFnZTogUGFnZSxwcml2YXRlIHJvdXRFeDpSb3V0ZXJFeHRlbnNpb25zKSB7XHJcbiAgICAgICAgcGFnZS5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hCdXR0b24oYXJnczogVG91Y2hHZXN0dXJlRXZlbnREYXRhKSB7XHJcbiAgICAgICAgbGV0IHNlbGVjY2lvbiA9IGFyZ3MuYWN0aW9uO1xyXG4gICAgICAgIGxldCBncmlkID0gPEJ1dHRvbj5hcmdzLm9iamVjdDtcclxuXHJcbiAgICAgICAgaWYgKHNlbGVjY2lvbiA9PSBcInVwXCIpIHtcclxuICAgICAgICAgICAgZ3JpZC5iYWNrZ3JvdW5kQ29sb3IgPSBuZXcgQ29sb3IoXCIjMDAyYWZmXCIpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGdyaWQuYmFja2dyb3VuZENvbG9yID0gbmV3IENvbG9yKFwiIzRlY2RjNFwiKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBtb3N0cmFyQ2xhdmUoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9zdHJhclBhc3MgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLmlzVHVybmVkT24gPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5tb3N0cmFyUGFzcyA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNUdXJuZWRPbiA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMubW9zdHJhclBhc3MgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcGFudGFsbGFSZWdpc3RyYXIoKXtcclxuICAgICAgICB0aGlzLnJvdXRFeC5uYXZpZ2F0ZShbXCJyZWdpc3RyYXJcIl0se1xyXG4gICAgICAgICAgICB0cmFuc2l0aW9uOntcclxuICAgICAgICAgICAgICAgIG5hbWU6XCJzbGlkZVRvcFwiLFxyXG4gICAgICAgICAgICAgICAgZHVyYXRpb246MjAwLFxyXG4gICAgICAgICAgICAgICAgY3VydmU6XCJsaW5lYXJcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICB9XHJcblxyXG4gICAgcmVhaXphckxvZ2luKCl7XHJcbiAgICBmaXJlYmFzZS5sb2dpbih7XHJcbiAgICB0eXBlOiBmaXJlYmFzZS5Mb2dpblR5cGUuUEFTU1dPUkQsXHJcbiAgICBwYXNzd29yZE9wdGlvbnM6IHtcclxuICAgICAgZW1haWw6ICdlZGR5dmVyYnJ1Z2dlbkBnbWFpbC5jb20nLFxyXG4gICAgICBwYXNzd29yZDogJ2ZpcmViYXNlJ1xyXG4gICAgfVxyXG4gIH0pLnRoZW4oXHJcbiAgICAgIGZ1bmN0aW9uIChyZXN1bHQpIHtcclxuICAgICAgICBKU09OLnN0cmluZ2lmeShyZXN1bHQpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdC51aWQpO1xyXG4gICAgICB9LFxyXG4gICAgICBmdW5jdGlvbiAoZXJyb3JNZXNzYWdlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3JNZXNzYWdlKTtcclxuICAgICAgfVxyXG4gICk7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbn0iXX0=