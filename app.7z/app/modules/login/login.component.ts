import { Component } from "@angular/core";
import { Page } from "ui/page";
import { TouchGestureEventData } from "tns-core-modules/ui/gestures/gestures";
import { Button } from "ui/button";
import { Color } from "tns-core-modules/color/color";
import { RouterExtensions} from "nativescript-angular/router";

import firebase = require("nativescript-plugin-firebase");

@Component({
    selector: "app-login",
    templateUrl: "./modules/login/login.component.html",
    styleUrls: ["./modules/login/login.component.css"]

})
export class LoginComponent {
    // Your TypeScript logic goes here
    public isTurnedOn: Boolean = false;
    public mostrarPass: Boolean = true;
    constructor(private page: Page,private routEx:RouterExtensions) {
        page.actionBarHidden = true;
    }

    onTouchButton(args: TouchGestureEventData) {
        let seleccion = args.action;
        let grid = <Button>args.object;

        if (seleccion == "up") {
            grid.backgroundColor = new Color("#002aff");
        } else {
            grid.backgroundColor = new Color("#4ecdc4");

        }
    }


    mostrarClave() {
        if (this.mostrarPass == true) {
            this.isTurnedOn = false;
            this.mostrarPass = false;
        } else {
            this.isTurnedOn = true;
            this.mostrarPass = true;
        }

    }

    pantallaRegistrar(){
        this.routEx.navigate(["registrar"],{
            transition:{
                name:"slideTop",
                duration:200,
                curve:"linear"
            }
        }
        )

    }

    reaizarLogin(){
    firebase.login({
    type: firebase.LoginType.PASSWORD,
    passwordOptions: {
      email: 'eddyverbruggen@gmail.com',
      password: 'firebase'
    }
  }).then(
      function (result) {
        JSON.stringify(result);
        console.log(result.uid);
      },
      function (errorMessage) {
        console.log(errorMessage);
      }
  );
    }






}