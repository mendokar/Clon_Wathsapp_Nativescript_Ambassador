"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var MenuComponent = (function () {
    function MenuComponent() {
    }
    return MenuComponent;
}());
MenuComponent = __decorate([
    core_1.Component({
        selector: "app-menu",
        templateUrl: "./modules/menu/menu.component.html",
        styleUrls: ["./modules/menu/menu.component.css"]
    })
], MenuComponent);
exports.MenuComponent = MenuComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtZW51LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEwQztBQU8xQyxJQUFhLGFBQWE7SUFBMUI7SUFFQSxDQUFDO0lBQUQsb0JBQUM7QUFBRCxDQUFDLEFBRkQsSUFFQztBQUZZLGFBQWE7SUFMekIsZ0JBQVMsQ0FBQztRQUNULFFBQVEsRUFBRSxVQUFVO1FBQ3BCLFdBQVcsRUFBQyxvQ0FBb0M7UUFDaEQsU0FBUyxFQUFDLENBQUMsbUNBQW1DLENBQUM7S0FDaEQsQ0FBQztHQUNXLGFBQWEsQ0FFekI7QUFGWSxzQ0FBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJhcHAtbWVudVwiLFxyXG4gIHRlbXBsYXRlVXJsOlwiLi9tb2R1bGVzL21lbnUvbWVudS5jb21wb25lbnQuaHRtbFwiLFxyXG4gIHN0eWxlVXJsczpbXCIuL21vZHVsZXMvbWVudS9tZW51LmNvbXBvbmVudC5jc3NcIl1cclxufSlcclxuZXhwb3J0IGNsYXNzIE1lbnVDb21wb25lbnQge1xyXG4gIC8vIFlvdXIgVHlwZVNjcmlwdCBsb2dpYyBnb2VzIGhlcmVcclxufSJdfQ==