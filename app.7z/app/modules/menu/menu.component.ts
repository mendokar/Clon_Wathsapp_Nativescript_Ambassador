import { Component } from "@angular/core";

@Component({
  selector: "app-menu",
  templateUrl:"./modules/menu/menu.component.html",
  styleUrls:["./modules/menu/menu.component.css"]
})
export class MenuComponent {
  // Your TypeScript logic goes here
}