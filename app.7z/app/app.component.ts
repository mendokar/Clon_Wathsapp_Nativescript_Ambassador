import { Component } from "@angular/core";

@Component({
  selector: "my-app",
  template: `<page-router-outlet></page-router-outlet>`
})
export class AppComponent {
  // Your TypeScript logic goes here
}
